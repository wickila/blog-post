#!/usr/bin/env python
# encoding: utf-8
"""
@author: wicki
@contact: gzswicki@gmail.com
@date: 16/8/13
"""


def print_tree(tree, reverse=False):
    def get_salient(lines):
        """ 获取节点的凸点 """
        return min([(line.find('+'), i) for i, line in enumerate(lines)])
    
    def get_lines(tree, depth):
        """ 获取某棵树的打印字符串 """
        lines = []
        if isinstance(tree, list):  # 此节点是列表,具有子节点
            sub_lines = get_lines(tree[0], depth + 1)  # 获取第一个子节点的打印字符串
            if len(sub_lines) > 1:  # 子节点还有子节点,则打印辅助符号"|",如果此段逻辑不懂。可以注释掉,看一下打印结果you什么区别
                salient, index = get_salient(sub_lines)  # 获取子节点的凸点行(子节点最终聚集在第几行)
                for i in range(index + 1, len(sub_lines)):  # 凸点行以下的行,全部加上"\"符号
                    sub_lines[i] = sub_lines[i][0: salient] + '|' + sub_lines[i][salient + 1:]
            lines.extend(sub_lines)

            lines.append("+--|".rjust((depth + 1) * 3, " "))  # 两个子节点之间的连接符号

            sub_lines = get_lines(tree[1], depth + 1)  # 获取第二个子节点的打印字符串
            if len(sub_lines) > 1:  # 子节点还有子节点,则打印辅助符号"|",如果此段逻辑不懂。可以注释掉,看一下打印结果you什么区别
                salient, index = get_salient(sub_lines)  # 获取子节点的凸点行(子节点最终聚集在第几行)
                for i in range(0, index):  # 凸点行以上的行,全部加上"\"符号
                    sub_lines[i] = sub_lines[i][0: salient] + '|' + sub_lines[i][salient + 1:]
            lines.extend(sub_lines)
        else:
            lines = ["+---".rjust((depth + 1) * 3, " ") + tree]
        return lines

    lines = get_lines(tree, 1)
    max_len = max([len(line) for line in lines])
    for i in range(len(lines)):
        line = lines[i]
        if i % 2 == 0:
            fragments = line.split('+---')
            name = fragments[1]
            fragments[1] = "-" * (max_len - len(line)) + fragments[1]
            line = '+---'.join(fragments)  # 右对齐
            if reverse:
                line = name + line.split(name)[0][::-1]
        else:
            if reverse:
                line += ' ' * (max_len - len(line))
                line = line[::-1]
        print line

tree = [[['Chihuahua', 'Yorkshire Terrier'], ['Great Dane', ['Bullmastiff', [['German Shepherd', 'Golden Retriever'], ['Standard Poodle', ['Boston Terrier', ['Brittany Spaniel', ['Border Collie', 'Portuguese Water Dog']]]]]]]]]

print_tree(tree[0], True)