# -*- encoding: UTF-8 -*-
'''
Created on 2015年7月13日

@author: wicki
'''
import web

urls = (
    '/', 'index',
    '/login','Login',
    '/logout','Logout',
    '/query',"Query"
)
render = web.template.render('templates/')

'''
    在处理请求前，先判断请求是否合法
'''
def need_check_session(function):
    def wrap_function(*args):
        session = web.config._session
        if session.user:
            return function(*args,user=session.user)
        else:
            return u"you're not login.plase login first."
    return wrap_function

class index:
    def GET(self):
        session = web.config._session
        return render.index(user=session.user)

class Login:
    def GET(self):
        return render.login()
    
    def POST(self):
        username = web.input()['username']
        session = web.config._session
        if username:
            session.user = username
            web.seeother('/')
        return "invalid username!!!"
    
class Logout:
    def GET(self):
        session = web.config._session
        session.kill()
        web.seeother("/")
        
class Query:
    @need_check_session
    def GET(self,user):
        return "haha.i know you're %s" % session.user

if __name__ == "__main__":
    app = web.application(urls, globals())
    #init session
    web.config.session_parameters['timeout'] = 86400 * 14,  #24 * 60 * 60 *14
    global session
    if '_session' not in web.config:
        session = web.session.Session(app, web.session.DiskStore('sessions'),
                                      initializer={'user': None})
        web.config._session = session
    else:
        session = web.config._session
    app.run()
