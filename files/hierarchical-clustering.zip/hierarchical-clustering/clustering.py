#!/usr/bin/env python
# encoding: utf-8
"""
聚类算法

@author: wicki
@contact: gzswicki@gmail.com
@date: 16/8/11
"""

import pandas as pd
import math


class HierarchicalClustering:
    def __init__(self, data, properties):
        self.properties = properties
        self.data = data.apply(self.normalize)
        self.distance = {}
        for i, row1 in self.data.iterrows():
            for j, row2 in self.data.iterrows():
                if i < j:
                    cls1 = row1.name
                    cls2 = row2.name
                    dis = math.sqrt(sum([math.pow(row1[col] - row2[col], 2) for col in properties]))  # 欧几里得距离
                    self.distance.setdefault(cls1, {})
                    self.distance.setdefault(cls2, {})
                    self.distance[cls1][cls2] = dis
                    self.distance[cls2][cls1] = dis
                    # print pd.DataFrame(self.distance)

    def normalize(self, col):
        """ 标准化某一列数据(修正的标准分) """
        if col.name in self.properties:
            median = col.median()  # 中位数
            ads = sum([math.fabs(col.iloc[i] - median) for i in range(len(col))]) / len(col)
            f = lambda x: (x - median) / ads
            return col.apply(f)
        return col

    def clustering(self):
        """ 层次聚类 """

        pool = [row.name for i, row in self.data.iterrows()]  # 初始化分类,每个样本是一个分类
        pl = len(pool)
        while pl > 1:
            temp = []  # 临时数组,纪录两两分类的距离
            for i in range(pl):
                for j in range(pl):
                    if i < j:
                        cluster1 = pool[i]
                        cluster2 = pool[j]
                        dis = self.calc_cluster_distance(cluster1, cluster2)
                        temp.append((dis, (cluster1, cluster2)))
            need_combine_1, need_combine_2 = min(temp)[1]  # 找到距离最近的两个分类
            # print '合并%s与%s, 距离为%f' % (need_combine_1, need_combine_2, min(temp)[0])  # 打印聚类过程
            pool.remove(need_combine_1)
            pool.remove(need_combine_2)
            pool.append([need_combine_1, need_combine_2])  # 把距离最近的两个分类合并成一个分类
            pl = len(pool)
        return pool

    def calc_cluster_distance(self, cluster1, cluster2):
        """ 计算两个类之间的距离(按照单链聚类) """

        def expand(cluster):
            """ 展开某个聚类中的所有元素,例如:
                    ['dog1',['dog2','dog3']] 返回['dog1', 'dog2', 'dog3']
             """
            result = []
            if isinstance(cluster, list):
                for c in cluster:
                    result.extend(expand(c))
            else:
                result.append(cluster)
            return result

        cluster1 = expand(cluster1)
        cluster2 = expand(cluster2)

        distances = []
        for c1 in cluster1:
            for c2 in cluster2:
                distances.append(self.distance[c1][c2])
        return min(distances)


if __name__ == "__main__":
    df = pd.read_csv('data/dogs.csv', index_col='class')
    cluster = HierarchicalClustering(df, ['height', 'weight'])

    print cluster.clustering()
